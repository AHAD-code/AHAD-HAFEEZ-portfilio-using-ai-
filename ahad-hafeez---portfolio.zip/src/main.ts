/**
 * AHAD HAFEEZ - PORTFOLIO INTERACTIVE SCRIPT
 * Written in Vanilla TypeScript / JavaScript (No frameworks)
 * Easy to read, edit, and maintain by Computer Science students.
 */

// Project Data Store for Dynamic Details Modal
const PROJECTS_DATA: Record<string, {
  title: string;
  category: string;
  tech: string[];
  description: string;
  architecture: string;
  features: string[];
}> = {
  'fuel-pump': {
    title: 'Fuel Pump Management System',
    category: 'Database Systems & Desktop C++',
    tech: ['C++', 'MySQL', 'SQL', 'ACID Transactions'],
    description: 'Designed and developed a database-based Fuel Pump Management System as an academic project. Created normalized relational database schemas and implemented full CRUD operations using SQL queries to record fuel sales, tank meter readings, and stock ledger updates.',
    architecture: 'C++ Console Application ➔ SQL Connector Driver ➔ MySQL Relational Storage Engine (Tables: Tanks, Meters, Attendants, Sales)',
    features: [
      'Normalized relational schema (1NF-3NF) preventing inventory data duplication',
      'CRUD transaction handlers for daily dispenser sales and attendant shifts',
      'Automated fuel reserve decrement calculation on sales log confirmation',
      'Daily sales reports with date filtering and revenue sum aggregations'
    ]
  },
  'expiry-guard': {
    title: 'Expiry Guard',
    category: 'Mobile Application Prototype',
    tech: ['MIT App Inventor', 'Mobile UX', 'Local Storage', 'Notification APIs'],
    description: 'Developed a mobile application prototype to track product expiry dates and implemented reminder-based notifications to help users monitor product expiration for grocery, dairy, and pharmaceutical items.',
    architecture: 'Screen Interface Layer ➔ Event-Driven Block Handlers ➔ Device Local TinyDB ➔ Push Notification Timers',
    features: [
      'Categorized storage views for Groceries, Medicine, Dairy, and Perishables',
      'Threshold date countdown calculation with automated reminder alerts',
      'Color-coded urgency status (Safe, Nearing Expiration, Expired)',
      'Offline-capable local item caching without external server requirements'
    ]
  },
  'cpp-academic': {
    title: 'C++ Academic Projects',
    category: 'Algorithms & Object-Oriented Systems',
    tech: ['C++', 'OOP', 'Data Structures', 'File I/O Streams'],
    description: 'Developed academic programming projects including a modular Calculator, a Student Management System, and a Library Management System. Applied object-oriented programming concepts such as classes, inheritance, and encapsulation along with basic data structures.',
    architecture: 'CLI Terminal Interface ➔ Domain Controller Classes (StudentManager, LibrarySystem) ➔ Data Structures (Linked Lists, Arrays) ➔ fstream Persistence',
    features: [
      'Encapsulation of student records and library items into robust C++ class hierarchies',
      'Implementation of linear data structures, search routines, and sorting algorithms',
      'File stream persistence (`ifstream`, `ofstream`) ensuring records survive app restarts',
      'Input validation loops and safe pointer arithmetic avoiding memory leaks'
    ]
  },
  'wordpress-portfolio': {
    title: 'Personal Portfolio Website',
    category: 'Web Design & Content Management',
    tech: ['WordPress', 'Web Design', 'Responsive CSS', 'SEO Basics'],
    description: 'Created a personal portfolio website using WordPress to showcase personal information, educational background, skills, and projects in a structured, accessible format for academic and professional visibility.',
    architecture: 'Web Browser Client ➔ Responsive Layout Engine ➔ WordPress CMS Core ➔ Contact Form Integration',
    features: [
      'Fully responsive multi-device layout tested across desktop, tablet, and mobile screens',
      'Structured sections highlighting university academic milestones and coursework',
      'Optimized lightweight assets for fast initial page load times',
      'Direct visitor inquiry integration with email routing'
    ]
  }
};

// Plain text version of CV for quick clipboard copy
const PLAIN_TEXT_CV = `
AHAD HAFEEZ
Computer Science Student | Aspiring Software Developer
Email: ahadhafeez01@gmail.com | Phone: +92 311 0684590 | Location: Lahore, Pakistan
LinkedIn: linkedin.com/in/ahadhafeez | University: University of Central Punjab, Lahore

EDUCATION
1. University of Central Punjab, Lahore (July 2024 – Present)
   Bachelor of Science in Computer Science (BSCS) — 4th Semester (CGPA: 3.31)
2. Punjab College, Allahabad (October 2022 – May 2024)
   Intermediate in Sciences (FSc) — Marks: 898 / 1200 (75%)
3. Hanif Memorial High School, Talwandi (2019 – 2021)
   Matriculation (Science) — Marks: 1090 / 1100 (99.1%)

TECHNICAL SKILLS
- Programming: C++ (OOP, DSA, File Streams, Pointers)
- Web Development: HTML5, CSS3, JavaScript (Basic)
- Database: SQL, MySQL (Relational Schema Design, Normalization, Queries, CRUD)
- Systems & Tools: WordPress, Computer Organization, Assembly Language (Basic)
- Soft Skills: Problem Solving, Teamwork, Critical Thinking

FEATURED PROJECTS
1. Fuel Pump Management System (C++, MySQL, SQL)
   Database-driven management solution with normalized schemas and SQL CRUD operations.
2. Expiry Guard (MIT App Inventor)
   Mobile application prototype to monitor product expiration with reminder push notifications.
3. C++ Academic Projects (C++, OOP, DSA)
   Calculator, Student Management System, and Library Management System implementing OOP and data structures.
4. Personal Portfolio Website (WordPress)
   Responsive web showcase for academic milestones, skills, and projects.

CERTIFICATIONS (COURSERA)
- Public Speaking with Canva
- Getting Started with Git and GitHub
- Introduction to HTML, CSS & JavaScript

LANGUAGES
- Urdu (Native) | Punjabi (Native) | English (Professional Working Proficiency)
`.trim();

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  initNavbarScroll();
  initSmoothScroll();
  initSkillFilters();
  initProjectFilters();
  initProjectDetailsModal();
  initCVModalActions();
  initToastAlerts();
  initContactForm();
  initBackToTop();
  initScrollAnimations();
});

/**
 * 1. Navbar Sticky & Scroll State
 */
function initNavbarScroll() {
  const navbar = document.getElementById('mainNavbar');
  const navLinks = document.querySelectorAll('.nav-link-custom');
  const sections = document.querySelectorAll('section[id]');

  window.addEventListener('scroll', () => {
    // Add backdrop shadow on scroll
    if (window.scrollY > 30) {
      navbar?.classList.add('scrolled');
    } else {
      navbar?.classList.remove('scrolled');
    }

    // ScrollSpy active link update
    const scrollPos = window.scrollY + 180;
    sections.forEach((section) => {
      const top = (section as HTMLElement).offsetTop;
      const height = (section as HTMLElement).offsetHeight;
      const id = section.getAttribute('id');

      if (scrollPos >= top && scrollPos < top + height) {
        navLinks.forEach((link) => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, { passive: true });
}

/**
 * 2. Smooth Scrolling & Mobile Menu Auto-Close
 */
function initSmoothScroll() {
  const navLinks = document.querySelectorAll('.nav-link-custom, a[href^="#"]');
  const navCollapse = document.getElementById('portfolioNav');

  navLinks.forEach((link) => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href && href.startsWith('#') && href.length > 1) {
        const targetSection = document.querySelector(href);
        if (targetSection) {
          e.preventDefault();
          targetSection.scrollIntoView({ behavior: 'smooth' });

          // Auto close mobile navbar collapse
          if (navCollapse && navCollapse.classList.contains('show')) {
            const bsCollapse = (window as any).bootstrap?.Collapse?.getInstance(navCollapse);
            if (bsCollapse) {
              bsCollapse.hide();
            } else {
              navCollapse.classList.remove('show');
            }
          }
        }
      }
    });
  });
}

/**
 * 3. Technical Skills Interactive Filters
 */
function initSkillFilters() {
  const filterBtns = document.querySelectorAll('[data-skill-filter]');
  const skillCards = document.querySelectorAll<HTMLElement>('.skill-card-item');

  filterBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      filterBtns.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-skill-filter');

      skillCards.forEach((card) => {
        const category = card.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

/**
 * 4. Projects Interactive Filters
 */
function initProjectFilters() {
  const projectBtns = document.querySelectorAll('[data-project-filter]');
  const projectCards = document.querySelectorAll<HTMLElement>('.project-card-item');

  projectBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      projectBtns.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-project-filter');

      projectCards.forEach((card) => {
        const categories = (card.getAttribute('data-category') || '').split(' ');
        if (filter === 'all' || (filter && categories.includes(filter))) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

/**
 * 5. Dynamic Project Details Modal
 */
function initProjectDetailsModal() {
  const modalButtons = document.querySelectorAll('[data-project-modal]');
  const modalEl = document.getElementById('projectDetailsModal');
  const titleEl = document.getElementById('modalProjectTitle');
  const catEl = document.getElementById('modalProjectCategory');
  const techEl = document.getElementById('modalProjectTech');
  const descEl = document.getElementById('modalProjectDesc');
  const archEl = document.getElementById('modalProjectArchitecture');
  const featuresEl = document.getElementById('modalProjectFeatures');

  modalButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const projectId = btn.getAttribute('data-project-modal');
      if (!projectId || !PROJECTS_DATA[projectId]) return;

      const data = PROJECTS_DATA[projectId];

      if (titleEl) titleEl.textContent = data.title;
      if (catEl) catEl.textContent = data.category;
      if (descEl) descEl.textContent = data.description;
      if (archEl) archEl.textContent = data.architecture;

      if (techEl) {
        techEl.innerHTML = `
          <span class="text-subtle font-medium">Stack:</span>
          ${data.tech.map((t, idx) => `
            <span class="text-purple font-mono">${t}</span>
            ${idx < data.tech.length - 1 ? '<span class="text-subtle">·</span>' : ''}
          `).join('')}
        `;
      }

      if (featuresEl) {
        featuresEl.innerHTML = data.features.map((feat) => `
          <div class="d-flex align-items-start gap-2 mb-2">
            <i class="bi bi-check2 text-cyan mt-1"></i>
            <span>${feat}</span>
          </div>
        `).join('');
      }

      // Open Modal via Bootstrap
      const bootstrapModal = (window as any).bootstrap?.Modal?.getOrCreateInstance(modalEl);
      bootstrapModal?.show();
    });
  });
}

/**
 * 6. CV Modal Actions (Copy Text & Print)
 */
function initCVModalActions() {
  const copyBtn = document.getElementById('copyCvTextBtn');
  const printBtn = document.getElementById('printCvBtn');

  copyBtn?.addEventListener('click', () => {
    navigator.clipboard.writeText(PLAIN_TEXT_CV).then(() => {
      showToast('Curriculum Vitae text copied to clipboard!');
    }).catch(() => {
      showToast('Copied CV text to clipboard.');
    });
  });

  printBtn?.addEventListener('click', () => {
    window.print();
  });
}

/**
 * 7. Toast Alerts System
 */
let toastTimeout: any = null;

function showToast(message: string) {
  const toastEl = document.getElementById('actionToast');
  const messageEl = document.getElementById('toastMessage');

  if (toastEl && messageEl) {
    messageEl.textContent = message;
    toastEl.classList.add('show');

    if (toastTimeout) clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3800);
  }
}

function initToastAlerts() {
  // Close toast button
  const closeBtn = document.getElementById('toastCloseBtn');
  closeBtn?.addEventListener('click', () => {
    document.getElementById('actionToast')?.classList.remove('show');
  });

  // Hero Email Copy button
  document.getElementById('copyHeroEmailBtn')?.addEventListener('click', () => {
    navigator.clipboard.writeText('ahadhafeez01@gmail.com');
    showToast('Copied email (ahadhafeez01@gmail.com) to clipboard!');
  });

  // Contact section copy buttons
  document.getElementById('copyContactEmailBtn')?.addEventListener('click', () => {
    navigator.clipboard.writeText('ahadhafeez01@gmail.com');
    showToast('Copied email: ahadhafeez01@gmail.com to clipboard!');
  });

  document.getElementById('copyContactPhoneBtn')?.addEventListener('click', () => {
    navigator.clipboard.writeText('+92 311 0684590');
    showToast('Copied phone number: +92 311 0684590 to clipboard!');
  });

  // Action buttons that give helpful student portfolio context
  document.querySelectorAll('.btn-action-toast').forEach((btn) => {
    btn.addEventListener('click', () => {
      const msg = btn.getAttribute('data-toast-msg');
      if (msg) showToast(msg);
    });
  });
}

/**
 * 8. Contact Form Handling
 */
function initContactForm() {
  const form = document.getElementById('contactForm') as HTMLFormElement;
  const directMailLink = document.getElementById('directMailtoLink') as HTMLAnchorElement;

  form?.addEventListener('submit', (e) => {
    e.preventDefault();

    const nameInput = document.getElementById('userName') as HTMLInputElement;
    const emailInput = document.getElementById('userEmail') as HTMLInputElement;
    const subjectInput = document.getElementById('userSubject') as HTMLInputElement;
    const messageInput = document.getElementById('userMessage') as HTMLTextAreaElement;

    if (!nameInput.value.trim() || !emailInput.value.trim() || !messageInput.value.trim()) {
      showToast('Please provide your name, email, and message.');
      return;
    }

    // Prepare direct mailto URL
    const subject = encodeURIComponent(subjectInput.value.trim() || `Portfolio Inquiry from ${nameInput.value.trim()}`);
    const body = encodeURIComponent(
      `Hello Ahad,\n\nName: ${nameInput.value.trim()}\nEmail: ${emailInput.value.trim()}\n\nMessage:\n${messageInput.value.trim()}`
    );
    const mailtoUrl = `mailto:ahadhafeez01@gmail.com?subject=${subject}&body=${body}`;

    if (directMailLink) {
      directMailLink.href = mailtoUrl;
    }

    showToast(`Thank you, ${nameInput.value.trim()}! Your message has been prepared.`);
    form.reset();
  });
}

/**
 * 9. Back To Top Button
 */
function initBackToTop() {
  const btn = document.getElementById('backToTopBtn');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 400) {
      btn?.classList.add('show');
    } else {
      btn?.classList.remove('show');
    }
  }, { passive: true });

  btn?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * 10. Subtle Scroll Reveal Animations
 */
function initScrollAnimations() {
  const elements = document.querySelectorAll('.reveal-on-scroll');

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      threshold: 0.1,
      rootMargin: '0px 0px -40px 0px'
    });

    elements.forEach((el) => observer.observe(el));
  } else {
    // Fallback if IntersectionObserver is unsupported
    elements.forEach((el) => el.classList.add('is-revealed'));
  }
}
